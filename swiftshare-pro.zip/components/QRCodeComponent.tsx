
import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

interface QRCodeComponentProps {
  value: string;
  size?: number;
}

export const QRCodeComponent: React.FC<QRCodeComponentProps> = ({ value, size = 256 }) => {
  return (
    <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 inline-block">
      <QRCodeSVG 
        value={value} 
        size={size}
        level="H"
        includeMargin={true}
        className="rounded-lg"
      />
    </div>
  );
};
