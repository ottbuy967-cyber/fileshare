
import React, { useState, useEffect, useRef } from 'react';
import { Camera, RefreshCw, X } from 'lucide-react';
import { Button } from './Button';

interface QRScannerProps {
  onScan: (data: string) => void;
  onClose: () => void;
}

export const QRScanner: React.FC<QRScannerProps> = ({ onScan, onClose }) => {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setHasPermission(true);
          setIsScanning(true);
        }
      } catch (err) {
        console.error("Camera access denied:", err);
        setHasPermission(false);
      }
    };

    startCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const simulateScan = () => {
    // In a real app, we'd use a library like jsQR to parse the video feed.
    // For this demo, we'll simulate finding a code after a short delay.
    setTimeout(() => {
      onScan("TRANSFER_MOCK_12345");
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col items-center justify-center p-4">
      <div className="relative w-full max-w-md aspect-square bg-gray-900 rounded-3xl overflow-hidden border-2 border-indigo-500 shadow-[0_0_50px_rgba(79,70,229,0.3)]">
        {hasPermission === false ? (
          <div className="flex flex-col items-center justify-center h-full p-8 text-center">
            <X className="w-16 h-16 text-red-500 mb-4" />
            <p className="text-white text-lg font-medium">Camera access denied</p>
            <p className="text-gray-400 mt-2">Please enable camera permissions to scan QR codes.</p>
          </div>
        ) : (
          <>
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full h-full object-cover opacity-60"
            />
            <div className="absolute inset-0 border-[40px] border-black/40">
              <div className="w-full h-full border-2 border-indigo-400/50 rounded-lg relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-indigo-500 shadow-[0_0_15px_rgba(79,70,229,1)] animate-scan-line" />
              </div>
            </div>
            
            <div className="absolute bottom-4 left-0 right-0 flex justify-center">
              <div className="bg-indigo-600/90 backdrop-blur-md px-4 py-2 rounded-full text-white text-xs font-bold uppercase tracking-widest animate-pulse">
                Scanning for code...
              </div>
            </div>
          </>
        )}
      </div>

      <div className="mt-8 flex gap-4">
        <Button variant="secondary" onClick={onClose} className="rounded-full px-6">
          <X className="w-5 h-5 mr-2" /> Cancel
        </Button>
        {hasPermission && (
          <Button variant="primary" onClick={simulateScan} className="rounded-full px-6">
            <RefreshCw className="w-5 h-5 mr-2" /> Simulate Scan
          </Button>
        )}
      </div>

      <style>{`
        @keyframes scan-line {
          0% { transform: translateY(0); }
          50% { transform: translateY(calc(100% - 1rem)); }
          100% { transform: translateY(0); }
        }
        .animate-scan-line {
          animation: scan-line 3s linear infinite;
        }
      `}</style>
    </div>
  );
};
