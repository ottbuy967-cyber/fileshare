
import React, { useState, useRef, useMemo } from 'react';
import { 
  Upload, 
  File as LucideFile, 
  Share2, 
  Download, 
  CheckCircle2, 
  Sparkles, 
  Plus, 
  Trash2,
  RefreshCw,
  Copy,
  Check,
  // Fix: added QrCode icon import to resolve "Cannot find name 'QrCode'" error.
  QrCode
} from 'lucide-react';
import { Button } from './Button';
import { QRCodeComponent } from './QRCodeComponent';
import { SharedFile } from '../types';
import { getFileInsights, summarizeTransfer } from '../services/geminiService';

interface FileTransferUIProps {
  mode: 'send' | 'receive';
  onComplete: () => void;
}

export const FileTransferUI: React.FC<FileTransferUIProps> = ({ mode, onComplete }) => {
  const [files, setFiles] = useState<SharedFile[]>([]);
  const [transferId, setTransferId] = useState<string | null>(null);
  const [step, setStep] = useState<number>(1); // 1: Prepare, 2: Action, 3: Completed
  const [isProcessing, setIsProcessing] = useState(false);
  const [insights, setInsights] = useState<Record<string, string>>({});
  const [batchSummary, setBatchSummary] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Generate a random 6-digit alphanumeric code for the transfer
  const shareCode = useMemo(() => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }, [transferId]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles: SharedFile[] = Array.from(e.target.files).map(f => ({
        id: Math.random().toString(36).substr(2, 9),
        name: f.name,
        size: f.size,
        type: f.type,
        lastModified: f.lastModified
      }));
      setFiles(prev => [...prev, ...newFiles]);
      
      // Fetch insights for each new file asynchronously
      newFiles.forEach(async (f) => {
        const insight = await getFileInsights(f.name, f.size, f.type);
        setInsights(prev => ({ ...prev, [f.id]: insight }));
      });
    }
  };

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const startSharing = async () => {
    setIsProcessing(true);
    // Simulate generation of unique transfer ID
    const mockId = `ss-${Math.random().toString(36).substr(2, 12)}`;
    setTransferId(mockId);
    
    // AI Batch Summary
    const summary = await summarizeTransfer(files);
    setBatchSummary(summary);
    
    setTimeout(() => {
      setIsProcessing(false);
      setStep(2);
    }, 1500);
  };

  const simulateDownload = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep(3);
    }, 3000);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(shareCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      {step === 1 && (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 tracking-tight">
              {mode === 'send' ? 'Prepare Your Package' : 'Ready to Receive'}
            </h2>
            <p className="mt-2 text-gray-500">
              {mode === 'send' 
                ? 'Select files to share securely via QR or Code' 
                : 'Scanned package detected. Review the files below.'}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <div 
                onClick={() => mode === 'send' && fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-3xl p-12 transition-all cursor-pointer flex flex-col items-center justify-center
                  ${mode === 'send' 
                    ? 'border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 hover:border-indigo-400' 
                    : 'border-emerald-200 bg-emerald-50/50'}`}
              >
                <input 
                  type="file" 
                  multiple 
                  ref={fileInputRef} 
                  onChange={handleFileSelect} 
                  className="hidden" 
                />
                <div className={`p-4 rounded-2xl mb-4 ${mode === 'send' ? 'bg-indigo-100 text-indigo-600' : 'bg-emerald-100 text-emerald-600'}`}>
                  {mode === 'send' ? <Upload className="w-10 h-10" /> : <Download className="w-10 h-10" />}
                </div>
                <h3 className="text-lg font-semibold text-gray-900">
                  {mode === 'send' ? 'Drop files here or click to browse' : 'Incoming files ready'}
                </h3>
                <p className="text-sm text-gray-500 mt-1">Unlimited file size, encrypted end-to-end</p>
                {mode === 'send' && (
                  <Button variant="outline" className="mt-6 rounded-full">
                    <Plus className="w-4 h-4 mr-2" /> Add Files
                  </Button>
                )}
              </div>

              {files.length > 0 && (
                <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                  <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                    <span className="text-sm font-medium text-gray-600">{files.length} Files Selected</span>
                    <span className="text-sm text-indigo-600 font-semibold">
                      {(files.reduce((acc, f) => acc + f.size, 0) / (1024 * 1024)).toFixed(2)} MB Total
                    </span>
                  </div>
                  <ul className="divide-y divide-gray-100 max-h-[400px] overflow-y-auto">
                    {files.map((file) => (
                      <li key={file.id} className="p-4 hover:bg-gray-50 transition-colors">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                              <LucideFile className="w-6 h-6" />
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-gray-900 truncate max-w-[200px]">{file.name}</p>
                              <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(1)} KB • {file.type || 'Unknown'}</p>
                            </div>
                          </div>
                          {mode === 'send' && (
                            <button onClick={() => removeFile(file.id)} className="text-gray-400 hover:text-red-500 p-1">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        {insights[file.id] && (
                          <div className="mt-3 flex items-start space-x-2 bg-indigo-50/50 p-2 rounded-xl">
                            <Sparkles className="w-4 h-4 text-indigo-500 mt-0.5 flex-shrink-0" />
                            <p className="text-[10px] leading-tight text-indigo-700 font-medium">{insights[file.id]}</p>
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="space-y-6">
              <div className="bg-indigo-900 rounded-3xl p-6 text-white shadow-xl shadow-indigo-200">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="w-5 h-5 text-indigo-300" />
                  <h4 className="font-bold text-lg">AI Smart Transfer</h4>
                </div>
                <p className="text-indigo-100 text-sm mb-6">
                  {files.length === 0 
                    ? "Upload files to see AI-powered security insights and organization tips." 
                    : "Our AI is analyzing your transfer for the best security protocols."}
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 text-xs text-indigo-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Dynamic compression active</span>
                  </div>
                  <div className="flex items-center space-x-3 text-xs text-indigo-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Peer-to-peer encryption ready</span>
                  </div>
                </div>
              </div>

              <Button 
                onClick={mode === 'send' ? startSharing : simulateDownload}
                disabled={files.length === 0 || isProcessing}
                fullWidth
                size="lg"
                className="rounded-full shadow-2xl h-16 text-lg"
              >
                {isProcessing ? (
                  <RefreshCw className="w-6 h-6 animate-spin mr-3" />
                ) : mode === 'send' ? (
                  <><Share2 className="w-6 h-6 mr-3" /> Create Transfer</>
                ) : (
                  <><Download className="w-6 h-6 mr-3" /> Download All</>
                )}
              </Button>
            </div>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="flex flex-col items-center justify-center py-8 space-y-8 animate-in zoom-in duration-500">
          <div className="text-center max-w-md">
            <h2 className="text-3xl font-extrabold text-gray-900">Your Share Link is Ready!</h2>
            <p className="mt-2 text-gray-500">
              The receiver can scan the QR code or enter the 6-digit code manually.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row items-center gap-12 w-full max-w-2xl">
            <div className="flex-1 flex flex-col items-center">
              <div className="relative">
                <QRCodeComponent value={transferId || "https://swiftshare.app"} />
                <div className="absolute -top-4 -right-4 bg-indigo-600 text-white p-2 rounded-full animate-bounce shadow-lg">
                  <QrCode className="w-6 h-6" />
                </div>
              </div>
              <p className="mt-4 text-xs font-bold text-gray-400 uppercase tracking-widest">Scan QR Code</p>
            </div>

            <div className="hidden lg:block w-px h-32 bg-gray-200"></div>

            <div className="flex-1 flex flex-col items-center w-full">
              <div 
                onClick={copyCode}
                className="bg-gray-50 border-2 border-dashed border-gray-200 p-8 rounded-3xl w-full flex flex-col items-center justify-center group cursor-pointer hover:border-indigo-400 hover:bg-white transition-all shadow-sm active:scale-95"
              >
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-4">Manual Code</p>
                <div className="text-4xl font-black text-indigo-600 tracking-[0.2em] mb-4 font-mono">
                  {shareCode}
                </div>
                <div className={`flex items-center space-x-2 text-xs font-bold px-3 py-1 rounded-full transition-colors ${copied ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500 group-hover:bg-indigo-100 group-hover:text-indigo-600'}`}>
                  {copied ? <><Check className="w-3 h-3" /> <span>Copied!</span></> : <><Copy className="w-3 h-3" /> <span>Click to copy</span></>}
                </div>
              </div>
            </div>
          </div>

          {batchSummary && (
            <div className="bg-white p-6 rounded-3xl border border-indigo-100 shadow-sm max-w-lg w-full">
              <div className="flex items-center space-x-2 mb-3">
                <Sparkles className="w-5 h-5 text-indigo-500" />
                <span className="font-bold text-indigo-900 uppercase tracking-wider text-xs">AI Package Insights</span>
              </div>
              <h4 className="text-gray-900 font-bold mb-1">{batchSummary.category} Package</h4>
              <p className="text-gray-600 text-sm italic">"{batchSummary.summary}"</p>
              <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
                <span className="text-xs text-gray-400">Suggested Name:</span>
                <span className="text-xs font-mono font-bold bg-gray-100 px-2 py-1 rounded-md">{batchSummary.suggestedFolderName}</span>
              </div>
            </div>
          )}

          <div className="flex flex-col items-center space-y-4">
            <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50 px-4 py-2 rounded-full text-sm font-medium">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Waiting for connection...</span>
            </div>
            <Button variant="secondary" onClick={() => setStep(1)} className="rounded-full">
              Back to edit
            </Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="flex flex-col items-center justify-center py-16 space-y-8 animate-in scale-95 duration-500">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-600" />
          </div>
          <div className="text-center max-w-md">
            <h2 className="text-3xl font-extrabold text-gray-900">Transfer Successful!</h2>
            <p className="mt-2 text-gray-500">
              All files have been transferred and verified using hash-check validation.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 w-full max-w-md">
            <div className="bg-gray-50 p-4 rounded-2xl text-center">
              <p className="text-xs text-gray-400 font-bold uppercase mb-1">Total Files</p>
              <p className="text-2xl font-black text-gray-900">{files.length}</p>
            </div>
            <div className="bg-gray-50 p-4 rounded-2xl text-center">
              <p className="text-xs text-gray-400 font-bold uppercase mb-1">Time Elapsed</p>
              <p className="text-2xl font-black text-gray-900">1.2s</p>
            </div>
          </div>

          <Button onClick={onComplete} className="rounded-full px-12 h-14 text-lg">
            Done
          </Button>
        </div>
      )}
    </div>
  );
};
