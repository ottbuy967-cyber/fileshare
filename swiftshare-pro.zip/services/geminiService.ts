
import { GoogleGenAI, Type } from "@google/genai";

// Always use const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFileInsights = async (fileName: string, fileSize: number, fileType: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Provide a very brief 1-sentence insight or security tip for a file named "${fileName}" of type "${fileType}" with size ${fileSize} bytes. If it's an image, mention possible optimizations. If it's a doc, mention privacy.`,
      config: {
        maxOutputTokens: 100,
        temperature: 0.7,
      },
    });
    return response.text || "No insights available for this file.";
  } catch (error) {
    console.error("Error fetching Gemini insights:", error);
    return "AI insights unavailable.";
  }
};

export const summarizeTransfer = async (files: { name: string, type: string }[]) => {
  const fileList = files.map(f => `${f.name} (${f.type})`).join(", ");
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Create a professional summary for a batch transfer containing these files: ${fileList}. Categorize them and suggest a folder name.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            category: { type: Type.STRING },
            suggestedFolderName: { type: Type.STRING }
          },
          required: ["summary", "category", "suggestedFolderName"]
        }
      },
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Error summarizing transfer:", error);
    return null;
  }
};
